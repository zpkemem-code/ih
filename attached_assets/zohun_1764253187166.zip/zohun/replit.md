# Zohun Telegram Bot

## Overview
Telegram userbot built with Pyrogram 2.0 for advanced Telegram automation features. The bot includes HTML blockquote support fix and comprehensive plugin system.

## Recent Changes (November 27, 2025)
- Fixed HTML blockquote rendering by applying parse_mode patch to Message class
- Made pytgcalls imports optional to resolve dependency conflicts
- Installed all required dependencies (pyrogram, aiohttp, google-generativeai, etc.)
- Bot successfully loads 201 modules

## Project Structure
```
Zohun/                  # Core bot framework
  __init__.py           # Main initialization with HTML patch
  __main__.py           # Bot entry point
  clients/              # Pyrogram client management
  database/             # SQLite database handlers
  helpers/              # Utility functions (tools, buttons, commands)
  logger.py             # Logging configuration

plugins/                # Bot command plugins
  anime.py              # Anime search features
  autoreport.py         # Auto report functionality
  alive_help.py         # Bot status and help commands
  ... (200+ plugins)

assistant/              # Bot assistant features
config/                 # Configuration management
storage/                # Session and data storage
```

## Key Features
- HTML blockquote rendering (auto-detects HTML tags)
- Plugin system with 200+ commands
- Multi-userbot support
- Spotify integration
- YouTube downloader
- AI integrations (Gemini, Groq)

## Environment Variables Required
- API_ID, API_HASH: Telegram API credentials
- BOT_TOKEN: Bot token from BotFather
- API_GEMINI: Google Gemini API key
- OWNER_ID: Owner's Telegram ID
- Other optional: SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET

## Running the Bot
```bash
python run_bot.py
```

## Technical Notes
- HTML patch is applied in Zohun/__init__.py using monkey-patching
- pytgcalls modules (streaming, vctools) are optional due to dependency conflicts
- The bot uses SQLite for local database storage
