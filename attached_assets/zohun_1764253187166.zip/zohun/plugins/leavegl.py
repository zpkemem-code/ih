__MODULE__ = "Leave Glimit"
__HELP__ = """
<b>✭ bantuan untuk leave glimit ✭</b>

<blockquote><b>✭ perintah : 
<code>{0}leaveallmute</code>
Untuk keluar dari grub yang membatasi anda</b></blockquote>
"""
